<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\library_information_system\library_information_system(backend)\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>